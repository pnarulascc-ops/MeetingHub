export type AccessType = 'department' | 'jmd' | 'cmd'
export type ExecutiveRole = 'jmd' | 'cmd'
export type SlotStatus = 'available' | 'booked' | 'blocked' | 'pending_approval' | 'approved' | 'rejected' | 'cancelled'

export type SessionContext = {
  accessType: AccessType
  departmentName: string | null
  displayName: string
  expiresAt: string
}

export type SessionRecord = SessionContext & {
  sessionToken: string
}

export type SlotView = {
  recordId: number | null
  meetingDate: string
  slotId: string
  executiveRole: ExecutiveRole
  status: SlotStatus
  departmentName: string | null
  bookedByName: string | null
  meetingPurpose: string | null
  note: string | null
  createdByRole: string | null
  createdByDisplayName: string | null
  isEmergency: boolean
}

export type ApprovalRequestView = {
  requestId: number
  meetingDate: string
  slotId: string
  executiveRole: ExecutiveRole
  status: 'pending_approval'
  departmentName: string
  bookedByName: string
  meetingPurpose: string
  remarks: string | null
  isEmergency: boolean
}

export type DepartmentRequestView = {
  requestId: number
  meetingDate: string
  slotId: string
  executiveRole: ExecutiveRole
  status: 'pending_approval' | 'approved' | 'rejected'
  bookedByName: string
  meetingPurpose: string
  remarks: string | null
  isEmergency: boolean
}

export type SummarySheetRow = {
  rowId: string
  meetingDate: string
  slotId: string
  executiveRole: ExecutiveRole
  departmentName: string
  attendeeName: string
  meetingPurpose: string
  status: 'booked' | 'pending_approval' | 'approved' | 'rejected'
  remarks: string | null
  createdAt: string
}

export const SESSION_STORAGE_KEY = 'meeting-scheduler-session-token'

export const EXECUTIVE_LABELS: Record<ExecutiveRole, string> = {
  jmd: 'JMD Dashboard',
  cmd: 'CMD Dashboard',
}

export const EXECUTIVE_SHORT_LABELS: Record<ExecutiveRole, string> = {
  jmd: 'JMD',
  cmd: 'CMD',
}

export function getTodayDate(): string {
  return new Date().toISOString().slice(0, 10)
}

export function formatHumanDate(value: string): string {
  const parsed = new Date(`${value}T00:00:00`)
  return new Intl.DateTimeFormat(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }).format(parsed)
}

export function getStatusLabel(status: SlotStatus): string {
  if (status === 'available') return 'Available'
  if (status === 'booked') return 'Booked'
  if (status === 'blocked') return 'Blocked'
  if (status === 'pending_approval') return 'Pending Approval'
  if (status === 'approved') return 'Approved'
  if (status === 'rejected') return 'Rejected'
  return 'Cancelled'
}

export function getStatusVariant(status: SlotStatus): 'default' | 'secondary' | 'warning' | 'destructive' | 'success' {
  if (status === 'available') return 'success'
  if (status === 'booked') return 'default'
  if (status === 'blocked') return 'secondary'
  if (status === 'pending_approval') return 'warning'
  if (status === 'approved') return 'success'
  return 'destructive'
}

export function isExecutive(accessType: AccessType): accessType is ExecutiveRole {
  return accessType === 'jmd' || accessType === 'cmd'
}

export function sortSlots(slots: SlotView[]): SlotView[] {
  return [...slots].sort((left, right) => {
    if (left.executiveRole !== right.executiveRole) {
      return left.executiveRole.localeCompare(right.executiveRole)
    }

    return left.slotId.localeCompare(right.slotId)
  })
}
